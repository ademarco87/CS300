// Alexander DeMarco
// SNHU CS300: Analysis and Design
// Professor Saba
// 6-30-24

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>

using namespace std;

// Class representing a course
class Course {
public:
    string courseNumber; // Course number
    string courseTitle;  // Course title
    vector<string> prerequisites; // List of prerequisites

    // Default constructor
    Course() : courseNumber(""), courseTitle(""), prerequisites({}) {}

    // Parameterized constructor
    Course(string number, string title, vector<string> prereqs)
        : courseNumber(number), courseTitle(title), prerequisites(prereqs) {}
};

// Function declarations
unordered_map<string, Course> readAndValidateFile(const string& filename);
void sortCoursesAlphanumerically(vector<string>& courseNumbers);
void searchAndPrintCourseInformation(const string& courseNumber, const unordered_map<string, Course>& courseDict);
void displayMenu();

int main() {
    unordered_map<string, Course> courseDict; // Dictionary to store course data
    vector<string> courseNumbers; // Vector to store sorted course numbers
    string filename = "ABCU_Advising_Program_Input.csv"; // Filename for the input file
    string courseNumber; // Variable to store user input course number
    int choice; // Variable to store user menu choice

    // Main loop for the menu
    while (true) {
        displayMenu(); // Display menu options
        cin >> choice; // Get user choice

        switch (choice) {
        case 1:
            // Load course data from file
            courseDict = readAndValidateFile(filename);
            if (!courseDict.empty()) {
                courseNumbers.clear();
                for (const auto& pair : courseDict) {
                    courseNumbers.push_back(pair.first); // Store course numbers
                }
                sortCoursesAlphanumerically(courseNumbers); // Sort course numbers
            }
            else {
                cout << "File validation failed." << endl;
            }
            break;
        case 2:
            // Print course list
            for (const auto& number : courseNumbers) {
                cout << number << ", " << courseDict[number].courseTitle << endl;
            }
            break;
        case 3:
            // Print course information
            cout << "Enter the course number: ";
            cin >> courseNumber;
            searchAndPrintCourseInformation(courseNumber, courseDict);
            break;
        case 9:
            // Exit the program
            cout << "Exiting program." << endl;
            return 0;
        default:
            // Invalid choice
            cout << "Invalid choice. Please try again." << endl;
        }
    }
}

// Function to read and validate course data from a file
unordered_map<string, Course> readAndValidateFile(const string& filename) {
    unordered_map<string, Course> courseDict; // Dictionary to store course data
    unordered_set<string> allCourses; // Set to track all course numbers
    ifstream file(filename); // Input file stream

    // Check if the file can be opened
    if (!file) {
        cerr << "Unable to open or read the file" << endl;
        return {};
    }

    string line;
    // Read each line from the file
    while (getline(file, line)) {
        stringstream ss(line);
        string courseNumber, courseTitle, prereq;
        vector<string> prerequisites;

        // Parse course number and title
        getline(ss, courseNumber, ',');
        getline(ss, courseTitle, ',');

        // Trim whitespace from course number and title
        courseNumber.erase(courseNumber.find_last_not_of(" \n\r\t") + 1);
        courseTitle.erase(courseTitle.find_last_not_of(" \n\r\t") + 1);

        if (courseNumber.empty() || courseTitle.empty()) {
            cerr << "Format error: Each line must contain at least a course number and title" << endl;
            continue; // Skip this line
        }

        // Parse prerequisites
        while (getline(ss, prereq, ',')) {
            prereq.erase(prereq.find_last_not_of(" \n\r\t") + 1); // Trim whitespace
            if (!prereq.empty()) {
                prerequisites.push_back(prereq);
            }
        }

        // Check if the course number already exists
        if (courseDict.find(courseNumber) != courseDict.end()) {
            cerr << "Duplicate course number found: " << courseNumber << endl;
            continue; // Skip this line
        }

        // Add course to dictionary
        courseDict[courseNumber] = Course(courseNumber, courseTitle, prerequisites);

        // Add course number to set
        allCourses.insert(courseNumber);
    }

    // Validate prerequisites
    for (const auto& pair : courseDict) {
        for (const auto& prereq : pair.second.prerequisites) {
            if (allCourses.find(prereq) == allCourses.end()) {
                cerr << "Format error: Prerequisite " << prereq << " does not exist as a course" << endl;
                return {};
            }
        }
    }

    file.close(); // Close the file
    return courseDict; // Return the course dictionary
}

// Function to sort course numbers alphanumerically
void sortCoursesAlphanumerically(vector<string>& courseNumbers) {
    sort(courseNumbers.begin(), courseNumbers.end());
}

// Function to search and print course information
void searchAndPrintCourseInformation(const string& courseNumber, const unordered_map<string, Course>& courseDict) {
    auto it = courseDict.find(courseNumber);
    if (it != courseDict.end()) {
        cout << "Course Number: " << it->second.courseNumber << endl;
        cout << "Course Title: " << it->second.courseTitle << endl;
        cout << "Prerequisites: ";
        if (!it->second.prerequisites.empty()) {
            for (size_t i = 0; i < it->second.prerequisites.size(); ++i) {
                cout << it->second.prerequisites[i];
                if (i < it->second.prerequisites.size() - 1) cout << ", ";
            }
        }
        else {
            cout << "None";
        }
        cout << endl;
    }
    else {
        cout << "Course not found" << endl;
    }
}

// Function to display the menu options
void displayMenu() {
    cout << "1. Load Course Data" << endl;
    cout << "2. Print Course List" << endl;
    cout << "3. Print Course Information" << endl;
    cout << "9. Exit" << endl;
    cout << "Enter your choice: ";
}
